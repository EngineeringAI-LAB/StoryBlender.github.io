from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from typing_extensions import override

from any_llm.any_llm import AnyLLM
from any_llm.utils.structured_output import get_json_schema, is_structured_output_type

MISSING_PACKAGES_ERROR = None
try:
    import together

    from .utils import (
        _convert_together_response_to_chat_completion,
        _create_openai_chunk_from_together_chunk,
    )
except ImportError as e:
    MISSING_PACKAGES_ERROR = e

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Sequence

    from together.types import (
        ChatCompletionChunk as TogetherChatCompletionChunk,
    )
    from together.types import (
        ChatCompletionResponse as TogetherChatCompletion,
    )

    from any_llm.types.completion import (
        ChatCompletion,
        ChatCompletionChunk,
        CompletionParams,
        CreateEmbeddingResponse,
    )
    from any_llm.types.model import Model


class TogetherProvider(AnyLLM):
    PROVIDER_NAME = "together"
    ENV_API_KEY_NAME = "TOGETHER_API_KEY"
    ENV_API_BASE_NAME = "TOGETHER_API_BASE"
    PROVIDER_DOCUMENTATION_URL = "https://together.ai/"

    SUPPORTS_COMPLETION_STREAMING = True
    SUPPORTS_COMPLETION = True
    SUPPORTS_RESPONSES = False
    SUPPORTS_COMPLETION_REASONING = True
    SUPPORTS_COMPLETION_IMAGE = True
    SUPPORTS_COMPLETION_PDF = False
    SUPPORTS_EMBEDDING = False
    SUPPORTS_LIST_MODELS = False
    SUPPORTS_BATCH = False

    MISSING_PACKAGES_ERROR = MISSING_PACKAGES_ERROR

    client: together.AsyncTogether

    @staticmethod
    @override
    def _convert_completion_params(params: CompletionParams, **kwargs: Any) -> dict[str, Any]:
        """Convert CompletionParams to kwargs for Together API."""
        converted_params = params.model_dump(
            exclude_none=True, exclude={"model_id", "messages", "response_format", "stream_options"}
        )
        if converted_params.get("reasoning_effort") in ("auto", "none"):
            converted_params.pop("reasoning_effort")
        if params.response_format is not None:
            if is_structured_output_type(params.response_format):
                converted_params["response_format"] = {
                    "type": "json_schema",
                    "schema": get_json_schema(params.response_format),
                }
            elif isinstance(params.response_format, dict):
                # Handle OpenAI-style dict format (e.g., {"type": "json_schema", "json_schema": {...}})
                # Together expects {"type": "json_schema", "schema": {...}}
                if params.response_format.get("type") == "json_schema":
                    json_schema = params.response_format.get("json_schema", {})
                    schema = json_schema.get("schema", json_schema)
                    converted_params["response_format"] = {
                        "type": "json_schema",
                        "schema": schema,
                    }
                else:
                    # Pass through other dict formats (e.g., {"type": "json_object"})
                    converted_params["response_format"] = params.response_format

        converted_params.update(kwargs)
        return converted_params

    @staticmethod
    @override
    def _convert_completion_response(response: Any) -> ChatCompletion:
        """Convert Together response to OpenAI format."""
        # We need the model parameter for conversion
        model = response.get("model", "together-model")
        return _convert_together_response_to_chat_completion(response, model)

    @staticmethod
    @override
    def _convert_completion_chunk_response(response: Any, **kwargs: Any) -> ChatCompletionChunk:
        """Convert Together chunk response to OpenAI format."""
        return _create_openai_chunk_from_together_chunk(response)

    @staticmethod
    @override
    def _convert_embedding_params(params: Any, **kwargs: Any) -> dict[str, Any]:
        """Convert embedding parameters for Together."""
        msg = "Together does not support embeddings"
        raise NotImplementedError(msg)

    @staticmethod
    @override
    def _convert_embedding_response(response: Any) -> CreateEmbeddingResponse:
        """Convert Together embedding response to OpenAI format."""
        msg = "Together does not support embeddings"
        raise NotImplementedError(msg)

    @staticmethod
    @override
    def _convert_list_models_response(response: Any) -> Sequence[Model]:
        """Convert Together list models response to OpenAI format."""
        msg = "Together does not support listing models"
        raise NotImplementedError(msg)

    @override
    def _init_client(self, api_key: str | None = None, api_base: str | None = None, **kwargs: Any) -> None:
        self.client = together.AsyncTogether(
            api_key=api_key,
            base_url=api_base,
            **kwargs,
        )

    async def _stream_completion_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncIterator[ChatCompletionChunk]:
        """Handle streaming completion with reasoning support."""
        from typing import cast

        response = cast(
            "AsyncIterator[TogetherChatCompletionChunk]",
            await self.client.chat.completions.create(
                model=model,
                messages=cast("Any", messages),
                **kwargs,
            ),
        )

        async for chunk in response:
            yield self._convert_completion_chunk_response(chunk)

    @override
    async def _acompletion(
        self,
        params: CompletionParams,
        **kwargs: Any,
    ) -> ChatCompletion | AsyncIterator[ChatCompletionChunk]:
        completion_kwargs = self._convert_completion_params(params, **kwargs)
        # Together API rejects empty tool_calls arrays
        cleaned_messages = [{k: v for k, v in msg.items() if k != "tool_calls" or v} for msg in params.messages]

        if params.stream:
            return self._stream_completion_async(
                params.model_id,
                cleaned_messages,
                **completion_kwargs,
            )

        response = cast(
            "TogetherChatCompletion",
            await self.client.chat.completions.create(
                model=params.model_id,
                messages=cast("Any", cleaned_messages),
                **completion_kwargs,
            ),
        )

        return self._convert_completion_response(response.model_dump())
