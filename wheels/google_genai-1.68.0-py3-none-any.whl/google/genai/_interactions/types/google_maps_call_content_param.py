# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import Base64FileInput
from .._utils import PropertyInfo
from .._models import set_pydantic_config
from .google_maps_call_arguments_param import GoogleMapsCallArgumentsParam

__all__ = ["GoogleMapsCallContentParam"]


class GoogleMapsCallContentParam(TypedDict, total=False):
    """Google Maps content."""

    id: Required[str]
    """A unique ID for this specific tool call."""

    type: Required[Literal["google_maps_call"]]

    arguments: GoogleMapsCallArgumentsParam
    """The arguments to pass to the Google Maps tool."""

    signature: Annotated[Union[str, Base64FileInput], PropertyInfo(format="base64")]
    """A signature hash for backend validation."""


set_pydantic_config(GoogleMapsCallContentParam, {"arbitrary_types_allowed": True})
